# Magic-The-Gathering_databse
This was a group assignment for a database management course at Towson University.
We were tasked with interviewing a real local business to identify an area of operation where we could assist by developing a database.
Titan Games & Hobbies in Lutherville was interviewed.
They were interested in a system that could catagorize magic the gathering cards based on attributes and physical condition of the card.
Our goal was to build a Java application to catagorize the cards and interface with an SQL database.
JavaApplication2 contains the relavant java files.
